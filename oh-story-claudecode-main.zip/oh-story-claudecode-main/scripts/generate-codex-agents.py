#!/usr/bin/env python3
"""Generate Codex custom-agent TOML templates from Claude agent markdown.

The Claude/OpenCode agent markdown remains the source of truth for role text.
Codex expects standalone TOML files with at least name, description, and
`developer_instructions`; this script performs a deterministic conversion.
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

READ_ONLY_AGENTS = {"chapter-extractor", "consistency-checker", "story-explorer"}
NICKNAMES = {
    "chapter-extractor": ["Chapter Extractor", "Scene Splitter"],
    "character-designer": ["Character Designer", "Voice Crafter"],
    "consistency-checker": ["Consistency Checker", "Continuity Guard"],
    "narrative-writer": ["Narrative Writer", "Prose Crafter"],
    "story-architect": ["Story Architect", "Plot Architect"],
    "story-explorer": ["Story Explorer", "Lore Scout"],
    "story-researcher": ["Story Researcher", "Source Scout"],
}


def parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    if not text.startswith("---\n"):
        raise ValueError("missing frontmatter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise ValueError("unterminated frontmatter")
    raw = text[4:end]
    body = text[end + len("\n---\n") :].lstrip()
    data: dict[str, str] = {}
    lines = raw.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#"):
            i += 1
            continue
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):(?:\s*(.*))?$", line)
        if not m:
            i += 1
            continue
        key, value = m.group(1), (m.group(2) or "").rstrip()
        if value == "|":
            block: list[str] = []
            i += 1
            while i < len(lines):
                nxt = lines[i]
                if nxt and not nxt.startswith((" ", "\t")):
                    break
                block.append(nxt[2:] if nxt.startswith("  ") else nxt.lstrip())
                i += 1
            data[key] = "\n".join(block).strip()
            continue
        data[key] = value.strip().strip('"').strip("'")
        i += 1
    return data, body


def toml_basic_string(value: str) -> str:
    # Use a multi-line basic string so Chinese instructions and Markdown remain readable.
    escaped = value.replace('\\', '\\\\').replace('"""', '\\\"\\\"\\\"')
    return f'"""\n{escaped.rstrip()}\n"""'


def toml_list(values: list[str]) -> str:
    return "[" + ", ".join(repr(v).replace("'", '"') for v in values) + "]"


# The Claude/OpenCode templates tell the agent to read references strictly in the order
# .claude/skills -> .opencode/skills -> skills/. For Codex, story-setup deploys the bundle
# to .codex/skills/..., so the agent must try that first; otherwise it reads non-existent
# paths and the appended Codex note (which says ".codex/skills first") contradicts the body.
_REF_BLOCK_RE = re.compile(
    r"1\. `\{项目根\}/\.claude/skills/story-setup/references/agent-references/([^`]+)`\n"
    r"2\. `\{项目根\}/\.opencode/skills/story-setup/references/agent-references/[^`]+`\n"
    r"3\. `\{项目根\}/skills/story-setup/references/agent-references/[^`]+`"
)


def _codex_reference_order(match: "re.Match[str]") -> str:
    fn = match.group(1)  # the {文件名} placeholder (or a concrete filename)
    return (
        f"1. `{{项目根}}/.codex/skills/story-setup/references/agent-references/{fn}`\n"
        f"2. `{{项目根}}/.claude/skills/story-setup/references/agent-references/{fn}`\n"
        f"3. `{{项目根}}/.opencode/skills/story-setup/references/agent-references/{fn}`\n"
        f"4. `{{项目根}}/skills/story-setup/references/agent-references/{fn}`"
    )


def adapt_body_for_codex(body: str, name: str) -> str:
    """Translate Claude/OpenCode caller terminology to Codex custom-agent wording."""
    adapted = body.replace("subagent_type", "agent_type")
    adapted = _REF_BLOCK_RE.sub(_codex_reference_order, adapted)
    return (
        adapted.rstrip()
        + "\n\n---\n\n"
        + "Codex adaptation notes:\n"
        + f"- Codex callers should request this custom agent with `agent_type: \"{name}\"` when the current runtime exposes project-local custom agents.\n"
        + "- If Codex reports `unknown agent_type` or the custom-agent registry is unavailable, the parent workflow must fall back to solo/direct execution and report the fallback instead of failing.\n"
        + "- Stay within this agent's role boundary; escalate adjacent work back to the parent agent.\n"
        + "- Use project-local story references first: `.codex/skills/story-setup/references/agent-references/`, then `.claude/skills/`, `.opencode/skills/`, then repository `skills/`.\n"
        + "- Do not assume Claude-only tool names or frontmatter fields exist in Codex.\n"
    )


def convert_file(src: Path, dst_dir: Path) -> Path:
    text = src.read_text(encoding="utf-8")
    meta, body = parse_frontmatter(text)
    name = meta.get("name") or src.stem
    description = meta.get("description", "").strip()
    if not description:
        raise ValueError(f"{src}: missing description")
    instructions = adapt_body_for_codex(body, name)
    out = [
        f"name = \"{name}\"",
        f"description = {toml_basic_string(description)}",
        f"nickname_candidates = {toml_list(NICKNAMES.get(name, [name]))}",
    ]
    if name in READ_ONLY_AGENTS:
        out.append('sandbox_mode = "read-only"')
    out.append(f"developer_instructions = {toml_basic_string(instructions)}")
    dst = dst_dir / f"{name}.toml"
    dst.write_text("\n".join(out) + "\n", encoding="utf-8")
    return dst


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source",
        default="skills/story-setup/references/templates/agents",
        help="Claude agent template directory",
    )
    parser.add_argument(
        "--dest",
        default="skills/story-setup/references/codex/agents",
        help="Codex TOML output directory",
    )
    args = parser.parse_args()
    src_dir = Path(args.source)
    dst_dir = Path(args.dest)
    dst_dir.mkdir(parents=True, exist_ok=True)
    generated = [convert_file(path, dst_dir) for path in sorted(src_dir.glob("*.md"))]
    for stale in dst_dir.glob("*.toml"):
        if stale not in generated:
            stale.unlink()
    print(f"Generated {len(generated)} Codex agent files in {dst_dir}")
    for path in generated:
        print(f"- {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
