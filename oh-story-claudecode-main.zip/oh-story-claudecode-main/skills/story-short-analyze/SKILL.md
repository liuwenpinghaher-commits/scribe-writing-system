---
name: story-short-analyze
version: 3.0.0
description: "短篇网文拆文。拆解爆款短篇小说（番茄短篇 / 故事会 / 知乎盐选 / 追妻 / 世情 / 重生 / 虐渣等通俗题材）的故事核、结构、情感线、反转设计、写作手法、共鸣层次。单一全量拆解管道：跑完 Stage 2-6 产出完整拆文报告，落盘到 拆文库/{书名}/，下游 story-short-write 同时读拆文报告 + 情节节点 + 写作手法 + 原文 + _meta.json 写下一篇。触发方式：/story-short-analyze、/短篇拆文、「拆短篇」「拆这篇短文」「短篇拆文」「精细拆解短篇」「8000 字短篇拆解」「番茄短篇拆文」「故事会拆解」「盐言故事拆解」「分析这篇短篇」——均进入同一管道。"
metadata: {"openclaw":{"source":"https://github.com/worldwonderer/oh-story-claudecode"}}
---
# story-short-analyze：短篇网文拆文

你是短篇小说结构分析师。

**核心：短篇靠共鸣和爆点驱动。拆文就是看它用什么故事核、怎么铺垫、在哪里引爆，把
分析叙事写进 `拆文报告.md`，结构计数写进 `_meta.json`，下一篇短篇直接读这些写。**

---

## 拆解边界声明（主线程同样适用）

短篇拆解的 Stage 2-6 全程由你（主线程）亲手做：拆的是用户**合法持有、拥有使用权**的虚构作品（已出版/连载或自有），性质是**只读的转化性文学批评**（编辑/评论/写作教学视角，不复制、不传播、不指导现实行为）。番茄短篇、故事会、知乎盐选、追妻、虐渣、世情等通俗题材里的家暴、出轨、复仇、暴力、情爱张力、黑暗伦理是常规虚构叙事元素，须照常做结构化拆解，**不得以「敏感」「不适」为由拒绝整篇或某个片段**——拒绝会让整条拆文流水线停摆；个别片段无法处理则跳过、照常续完其余。

---

## Phase 1：确认拆解对象 + 字数路由 + 续跑检查

### 1.1 拿到原文

问用户：**「你要拆哪篇？（标题+平台/来源）」**

**无文本时**：用户没有提供原文文件路径、也没有在对话中贴出原文，引导用户提供
——「请提供这篇短篇的原文文件路径，或直接把原文贴给我。」

### 1.2 字数检查（长短篇路由）

拿到原文后立刻数字数：

```
word_count = 全文字数
  ├─ < 15,000          → 直接进入 short 管道
  ├─ 15,000 - 20,000   → 灰区：询问用户「字数 {N}，介于短/长之间，按短篇还是长篇拆？」
  └─ > 20,000          → 提示「此文字数 {N} 偏长，建议改用 /story-long-analyze。
                           仍要按短篇拆请明确回复『按短篇继续』」
```

**为什么必须探针**：短篇与长篇的节点密度、情感曲线节奏、共鸣层数差异显著；用短篇
管道拆 100k+ 长篇会把节点采样过疏，模型把单卷误判成全书。

### 1.3 题材识别

```
用户提到具体题材（追妻 / 重生 / 虐文 / ...）？
  ├─ 是 → 加载 genre-catalog.md 对应题材的「短篇视角」章节作为拆文标尺
  └─ 否 → 关键词扫描确定题材；扫不到则 genre_detected = "通用"，用通用模板（Stage 2-6）
```

题材识别关键词参考：

- 追妻火葬场 / 渣男后悔 → 追妻
- 重生复仇 / 前世今生 → 重生复仇
- 死后视角 / 灵魂旁观 → 死人文学
- 小三 / 出轨 / 知三当三 → 小三
- 世情 / 现实 / 婆媳 → 世情
- 仙侠 / 修仙 / 门派 → 仙侠

题材作为「对照标尺」加载——见 `references/genre-catalog.md` 等文件首段「## 用作
拆文标尺时」说明。

### 1.4 续跑检查（lightweight resume）

进入管道前检查 `拆文库/{书名}/_meta.json`：

```
存在 _meta.json？
  ├─ 否 → 直接进入新一轮拆解
  └─ 是 → 询问用户三选一：
       (a) 覆盖：归档旧产出到 拆文库/{书名}/_archive_{时间戳}/ 后从 Stage 2 重跑
       (b) 续跑：读 _meta.json.last_stage_in_progress（非空 → 从该 Stage 整段重跑）
                 或读 _meta.json.stages_completed[]（从 max+1 续跑）
       (c) 取消
```

完整 resume 契约见 [references/output-contract.md](references/output-contract.md)。

---

## 输出目录

输出到 `拆文库/{书名}/`（项目根目录下）。用户指定了其他路径时按用户指定路径输出。

**标准输出文件树**：

```
拆文库/{书名}/
├── 原文/                # 原文备份（管道前置步骤产出）
├── 拆文报告.md           # 人类可读综合报告（Stage 2-6 所有可读段）
├── 情节节点.md           # Stage 2 情节节点清单（独立成文，方便定位）
├── 写作手法.md           # Stage 4 写作手法分析（独立成文，方便复用）
└── _meta.json           # 管道元数据 + 结构计数（resume + Phase 7 数值依据）
```

> **下游契约**：`story-short-write` 同时读全套产出——`拆文报告.md` 取分析叙事，
> `情节节点.md` 看节奏锚点，`写作手法.md` 抄手法，`原文/` 抄语感，`_meta.json`
> 看题材识别和结构计数。完整字段定义见
> [references/output-contract.md](references/output-contract.md)。

### Stage → 文件映射

| Stage | 落地文件 |
|-------|----------|
| 2 | `拆文报告.md`（故事核+结构+梗概段） + `情节节点.md` |
| 3 | `拆文报告.md`（情感曲线+爆点段） |
| 4 | `拆文报告.md`（反转段） + `写作手法.md` |
| 5 | `拆文报告.md`（人物+首尾段） |
| 6 | `拆文报告.md`（综合段） + `_meta.json.structure_counts`（数值计入元数据） |

### 原文备份（管道前置步骤）

**拆解开始前，必须先备份原文**：

1. 检查 `拆文库/{书名}/原文/` 目录是否已存在
2. 如果不存在，从用户提供的源路径复制原文文件到 `拆文库/{书名}/原文/`
3. 如果用户未提供源文件路径（直接在对话中贴文本），将原始文本保存到
   `拆文库/{书名}/原文/原文.md`
4. 备份完成后验证 `原文/` 目录下文件非空（>0 bytes）
5. 此步骤确保即使拆文过程中出现异常，原始材料不会丢失

备份完成后初始化 `_meta.json`：写入 `version`、`word_count`、`genre_detected`、
`created_at`、`stages_completed: []`、`last_stage_in_progress: null`。

---

## Stage 2-6：拆文流程

### 5 阶段管道

**预期耗时提示**：短篇拆文通常 10-30 分钟；同类对比或平台适配会更久。若文本很短，
先只挑关键节点，不要为满足节点数量硬拆。

| 阶段 | 名称 | 输入 | 输出 | 完成标志 |
|------|------|------|------|----------|
| 2 | 结构+情节节点 | 全文 | 故事核 + 故事梗概 + 功能分段（4-6段，必须含开端/发展/高潮/结局）+ 情节节点清单。节点密度按字数分档，见 material-decomposition.md「情节节点提取」的字数分档表。 | 结构划分 ≥4 段 + 故事核已提取 |
| 3 | 情感线+爆点 | 故事核+结构划分+情节节点数据 | 情感曲线（≥5节点）+ 爆点分析（6维度）+ 期待感分析。 | 爆点分析 6 维度齐全 |
| 4 | 反转+写作手法 | 节点+情感数据 | 前置反转检查 + 反转机制（铺垫≥2条）+ 写作手法（≥5项维度：POV/对话/时间/信息/其他）。 | 写作手法 ≥5 项 |
| 5 | 人物+开头结尾 | 情节节点+全文 | 所有人物（分类+功能标签+功能评估）+ 开头分析（前50/100字）+ 结尾分析（收束检查）。 | 人物功能评估完成 |
| 6 | 综合评估 + `_meta.json` 写计数 | 全部数据 | 五维评分 + 爆点性 + 话题性 + 共鸣分析（≥3层）+ 可复用结构（≥3条）+ 节奏速报 + **算出并写入 `_meta.json.structure_counts`**。 | 五维评分完成 + 爆点性/话题性已分析 + 共鸣≥3层 + 可复用≥3条 + 节奏速报已包含 + `_meta.json.structure_counts` 各字段达 Phase 7.2 阈值 |

> 管道执行顺序：2 → 3 → 4 → 5 → 6（严格串行，每阶段依赖前一阶段数据）。可选模块
> （同类对比、平台适配、详细节奏）可在 Stage 6 后执行。

**Stage 写盘协议**（crash safety）：每个 Stage 开始前先把 `_meta.json.last_stage_in_progress`
置为当前 Stage 编号；该 Stage 所有目标文件写完后再做 non-empty / 最小长度检查，通过
才清空 `last_stage_in_progress` 并 append 到 `stages_completed[]`。半成品文件不被
信任，resume 时该 Stage 整段重跑。完整协议见
[references/output-contract.md](references/output-contract.md) 「写入顺序 (crash safety)」段。

**非标文本分段**：对话体、聊天记录、帖子体、书信体等非标准章节格式，先按时间/说话人
切换/信息揭示点分段，再映射到开端、发展、高潮、结局；不要机械按自然段数量切分。

详细模板见 [output-templates.md](references/output-templates.md)，方法论见
[material-decomposition.md](references/material-decomposition.md)，输出契约见
[output-contract.md](references/output-contract.md)。

---

## Phase 7：检查验收（Stage 6 之后、写 stages_completed[6] 之前）

Stage 6 内容写完后，**不**立刻 append `6` 到 `stages_completed[]`。先跑三道检查：

### 7.1 拆文报告 AI 腔自检

扫描 `拆文报告.md` 全文 against [references/banned-words.md](references/banned-words.md)
词表 + [references/anti-ai-writing.md](references/anti-ai-writing.md) 句式规则。
扫描时跳过源文引用——以 `>` 开头的引用行、以及表格中「关键台词 / 原文引用」列的引号直引不计入，只扫分析师本人写的措辞。

- **命中** → 不写 `stages_completed[6]`，列出命中位置，提示用户人工修订**拆文报告
  本身**的 AI 腔（不是源文——源文里有 AI 腔正常报告即可，但报告本身不能写成 AI 腔）。
- **未命中** → 继续 7.2。

> 守门员定位：本节检查「我们写的拆文报告」；不要评价「源文是否 AI 写的」。

### 7.2 `_meta.json.structure_counts` 数值校验

按 [references/output-contract.md](references/output-contract.md) 「Phase 7.2」表
逐项检查 `_meta.json` 里 Stage 6 写入的结构计数。阈值与 carve-out 以 output-contract.md 为准（单一权威，不在此重复内联表以免漂移）——特别注意两条合法产出态：`reversal_type` 枚举**含「无反转」**（甜宠/喜剧/报应型）；`reversal_type=无反转` 时 **`setup_clues` 跳过该行、不计入阻断**。

任一项不达标 → 阻断；列出未达标字段，提示用户回到对应 Stage 补足。

### 7.3 `output-templates.md` [BLOCK] 项扫描

扫描 `output-templates.md` 中所有 `[BLOCK]` 标注项，确认对应产出段已完成。任一缺失
→ 阻断。`[WARN]` 项不阻断，但写入 `拆文报告.md` 末尾的「待补」清单供用户决定。

### 7.4 通过

7.1 + 7.2 + 7.3 全通过 → 清空 `_meta.json.last_stage_in_progress`，append `6` 到
`stages_completed[]`，提示用户「拆解完成，可调用 `/story-short-write` 写下一篇」。

---

## 质量检查概要

各阶段完成后需通过质量检查。逐项 checklist 见
[output-templates.md 质量检查必填字段](references/output-templates.md)。

质量标准的阈值、数值与计算方式的唯一权威定义见
[material-decomposition.md 质量标准](references/material-decomposition.md)。

强阻断 / 警告区分：见 `output-templates.md` 每条 checklist 末尾的 `[BLOCK]` /
`[WARN]` 标注。`[BLOCK]` 不通过 → Phase 7.3 阻断。

---

## 流程衔接

**流水线：** 短篇
**位置：** 拆文（第 2/3 步）

| 时机 | 跳转到 | 命令 |
|---|---|---|
| 准备开写 | story-short-write（同时读 拆文报告.md + 情节节点.md + 写作手法.md + 原文/ + _meta.json） | `/story-short-write` |
| 需要市场数据 | story-short-scan | `/story-short-scan` |
| 字数 > 20k 更适合长篇 | story-long-scan → story-long-analyze | `/story-long-scan` |

---

## 参考资料

### 核心方法论（拆文时必须加载）

| 文件 | 何时加载 |
|------|----------|
| [references/output-contract.md](references/output-contract.md) | 全程：Stage→文件映射 / `_meta.json` schema（含 structure_counts）/ 下游消费规范 / Phase 7 检查接入点 |
| [references/output-templates.md](references/output-templates.md) | 拆文时：输出模板 + 结构库 + 质量检查（含 [BLOCK]/[WARN] 标注） |
| [references/material-decomposition.md](references/material-decomposition.md) | 拆文方法论：情节节点提取 + 写作手法 + 情感线 + 节奏分析 + 共鸣分析 + 人物规则 + **质量标准唯一权威** |
| [references/quality-checklist.md](references/quality-checklist.md) | 评估**源文**质量时：短篇拆书的质量自检清单（评估对象的好坏，不是评估拆文报告本身） |
| [references/anti-ai-writing.md](references/anti-ai-writing.md) | Phase 7.1：扫描**拆文报告本身**的 AI 腔（不是源文滤镜） |
| [references/banned-words.md](references/banned-words.md) | Phase 7.1：拆文报告禁用词速查 |

### 按需加载（拆解对应题材 / 维度时作为对照标尺）

| 文件 | 何时加载 |
|------|----------|
| [references/deconstruction-examples.md](references/deconstruction-examples.md) | 校准拆文方法时：3 个完整案例作为参照 |
| [references/zhihu-style.md](references/zhihu-style.md) | 拆解知乎盐言故事时作为平台特性对照 |
| [references/genre-catalog.md](references/genre-catalog.md) | 拆解特定题材时：加载对应题材的「短篇视角」章节作为标准模式 |
| [references/hooks-chapter.md](references/hooks-chapter.md) | 拆解章节钩子设计时作为钩子类型对照 |
| [references/hooks-suspense.md](references/hooks-suspense.md) | 拆解悬念设计时作为悬念分类对照 |
| [references/hooks-paragraph.md](references/hooks-paragraph.md) | 拆解段落钩子时作为 11 种段落级钩子对照 |
| [references/character-basics.md](references/character-basics.md) | 拆解人物基础设定时作为人设要素对照 |
| [references/character-design-methods.md](references/character-design-methods.md) | 拆解人物内在矛盾时作为三层标签反差对照（contradiction_axis 来源） |
| [references/character-relations.md](references/character-relations.md) | 拆解人物关系网时作为关系类型对照 |
| [references/genre-core-mechanics.md](references/genre-core-mechanics.md) | 拆解题材核心梗与循环机制时作为机制对照 |
| [references/genre-readers.md](references/genre-readers.md) | 拆解读者心理与期待管理时作为读者画像对照 |

### 补充资料（拆 Stage 6「可复用结构」时按需对照）

> **题材写作公式**：`references/genre-writing-formulas.md`（21 大题材公式作为
> 「这篇是否合标」的对照标尺）
> **通用写作技法**：`references/genre-writing-techniques.md`（情绪操控 / 感情线 /
> 震惊场景 / 喜剧机制——拆 reusable_structures.fail_mode 时引用 L329 「禁忌」列）
> **市场数据**：`references/real-market-data.md`（跨平台写作差异对照表）

所有 references 在 `story-short-analyze` 中都是**对照标尺**——用源文与文件描述的
标准模式做对比，找出该篇用了哪种、做得多到位，**不是**按文件指引写新作品。

---

## 语言

- 跟随用户的语言回复，用户用什么语言就用什么语言回复
- 中文回复遵循《中文文案排版指北》
